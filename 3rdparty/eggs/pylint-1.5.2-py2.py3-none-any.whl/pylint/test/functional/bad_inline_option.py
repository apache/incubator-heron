"""errors-only is not usable as an inline option"""
# +1: [bad-inline-option]
# pylint: errors-only

CONST = "This is not a pylint: inline option."
