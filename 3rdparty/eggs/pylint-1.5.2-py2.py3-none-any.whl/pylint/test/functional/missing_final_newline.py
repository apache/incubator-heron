"""This file does not have a final newline."""
from __future__ import print_function
# +1:[missing-final-newline]
print(1)