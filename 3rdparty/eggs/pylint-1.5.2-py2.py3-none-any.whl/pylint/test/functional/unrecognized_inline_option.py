# +1: [unrecognized-inline-option]
# pylint:bouboule=1
"""Check unknown option"""
