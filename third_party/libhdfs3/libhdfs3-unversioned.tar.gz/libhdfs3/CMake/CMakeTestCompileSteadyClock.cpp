#include <chrono>

using std::chrono::steady_clock;

void foo(const steady_clock &clock) {
    return;
}
