#!/bin/sh
cat <<EOF
Please send email to krb5-bugs@mit.edu to report bugs.

It is helpful to include the Kerberos version and operating system
information with your bug report.  Please note that bug reports are
public; if you are reporting a security vulnerability, send mail to
krbcore-security@mit.edu instead, ideally using PGP encryption.
EOF
