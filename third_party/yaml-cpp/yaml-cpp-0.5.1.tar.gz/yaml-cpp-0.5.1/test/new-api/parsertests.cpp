#include "parsertests.h"

namespace Test {
	bool RunParserTests()
	{
		return true;
	}
}
